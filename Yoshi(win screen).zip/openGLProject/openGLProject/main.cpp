#include <glad\glad.h>
#include <GLFW\glfw3.h>
#include <iostream>
#include <string>
#include <sstream>//string stream
#include "Shader.h"

#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#define STB_IMAGE_IMPLEMENTATION //so it wont go looking for the c or cpp file
#include "stb_image.h"

#include "Camera.h"

using namespace std;


bool wireFrame = false;

//camera
Camera camera(glm::vec3(0.0f, 0.0f, 3.0f));
float lastX = 400, lastY = 300;
bool firstMouse = true;

//Time management stuff
float deltaTime = 0.0f; //time between current frame and last frame
float lastFrame = 0.0f; //time of last frame


//user inputs
void processInputs(GLFWwindow* window);


//Frames Per Second prototype
void showFPS(GLFWwindow* window); 

//Vertex Shader Program Source Code
const char* vertexShaderSource =
"#version 330 core\n"
"layout(location = 0) in vec3 aPos;\n" //variable location[0], read value in of type vec3
"\n"
"void main()\n"
"{\n"
"    gl_Position = vec4(aPos.x, aPos.y, aPos.z, 1.0);\n"
"}\n\0";//need \0 to tell it its the end of the character string

//Fragment Shader Program Source Code
const char* fragmentShaderSource =
"#version 330 core\n"
"out vec4 FragColor;\n" //value passed on to next shader when done
"\n"
"void main()\n"
"{\n"
"FragColor = vec4(1.0f, 0.5f, 0.2f, 1.0f);\n"
"}\n\0";



void main()
{
	glfwInit();
	//tell glfw that we want to work with openGL 3.3 core profile
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3); //the first 3 of 3.3
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3); //the .3 of 3.3
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE); //core profile

	//build window
	GLFWwindow *window = glfwCreateWindow(1280, 720, "Yoshi Snake", NULL, NULL);
	//if it fails
	if (window == NULL){
		//try report error
		cout << "failed to create window" << endl;
		glfwTerminate(); //cleanup glfw stuff
		system("pause");
		return;
	}
	//make this window the current one
	glfwMakeContextCurrent(window);

	//initialise GLAD
	if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress)){
		//if this fails, then
		cout << "GLAD failed to initialise" << endl;
		glfwTerminate(); //cleanup glfw stuff
		system("pause");
		return;
	}

	//set up openGL viewport x,y,w,h
	glViewport(0, 0, 1280, 720);//you dont have to use the full window for openGL but we will

	//set z depth buffering on
	glEnable(GL_DEPTH_TEST);

	//load images in, flip them
	stbi_set_flip_vertically_on_load(true);




	
	Shader shaderProgram2("cubeVertexShader.txt", "cubeFragmentShader.txt");


	//Compile Shader Source into shader programs
	//vertex shader first
	int vertexShaderID = glCreateShader(GL_VERTEX_SHADER);//gives id for a vertex shader
	//give it the source code
	//params:
	//		shader id
	//		number of source strings
	//		source strings (1 or array)
	//		length of string or NULL if it ends in a \0
	glShaderSource(vertexShaderID, 1, &vertexShaderSource, NULL);
	//compile the code on the gpu
	glCompileShader(vertexShaderID);

	//check for errors
	int success;
	char infoLog[512];
	//check compile status for our program, store result in success
	glGetShaderiv(vertexShaderID, GL_COMPILE_STATUS, &success);
	//failed?
	if (!success){
		//get error for the log and store in infoLog
		glGetShaderInfoLog(vertexShaderID, 512, NULL, infoLog);
		cout << "Vertex shader error!: " << infoLog << endl;
		system("pause");
	}
	//Fragment shader
	int fragmentShaderID = glCreateShader(GL_FRAGMENT_SHADER);
	glShaderSource(fragmentShaderID, 1, &fragmentShaderSource, NULL);
	glCompileShader(fragmentShaderID);

	glGetShaderiv(fragmentShaderID, GL_COMPILE_STATUS, &success);
	//failed?
	if (!success){
		//get error for the log and store in infoLog
		glGetShaderInfoLog(fragmentShaderID, 512, NULL, infoLog);
		cout << "Fragment shader error!: " << infoLog << endl;
		system("pause");
	}
	//Create a Shader Program which links a bunch of shaders together for a full pipeline
	int shaderProgramID = glCreateProgram();
	//attach our shaders to this program
	glAttachShader(shaderProgramID, vertexShaderID);
	glAttachShader(shaderProgramID, fragmentShaderID);
	//link the attached shaders
	glLinkProgram(shaderProgramID);
	//check for linking errors
	glGetProgramiv(shaderProgramID, GL_LINK_STATUS, &success);
	if (!success){
		glGetProgramInfoLog(shaderProgramID, 512, NULL, infoLog);
		cout << "Shader Program Linking Error!: " << infoLog << endl;
		system("pause");
	}
	//our shaders were used to help make the full shader program, we dont need them individually anymore
	glDeleteShader(vertexShaderID);
	glDeleteShader(fragmentShaderID);


	float textureRectVertices[] = {
		// positions // colors // texture coords
		1, 1, 0.0f, 1.0f, 0.0f, 0.0f, 1.0f, 1.0f, // top right
		1, -1, 0.0f, 0.0f, 1.0f, 0.0f, 1.0f, 0.0f, // bottom right
		-1, -1, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, // bottom left
		-1, 1, 0.0f, 1.0f, 1.0f, 0.0f, 0.0f, 1.0f // top left 
	};



	float textureCubVertices[] = {
		//x		y		z	tenX	tenY
		-0.5f, -0.5f, -0.5f, 0.0f, 0.0f,
		0.5f, -0.5f, -0.5f, 1.0f, 0.0f,
		0.5f, 0.5f, -0.5f, 1.0f, 1.0f,
		0.5f, 0.5f, -0.5f, 1.0f, 1.0f,
		-0.5f, 0.5f, -0.5f, 0.0f, 1.0f,
		-0.5f, -0.5f, -0.5f, 0.0f, 0.0f,

		-0.5f, -0.5f, 0.5f, 0.0f, 0.0f,
		0.5f, -0.5f, 0.5f, 1.0f, 0.0f,
		0.5f, 0.5f, 0.5f, 1.0f, 1.0f,
		0.5f, 0.5f, 0.5f, 1.0f, 1.0f,
		-0.5f, 0.5f, 0.5f, 0.0f, 1.0f,
		-0.5f, -0.5f, 0.5f, 0.0f, 0.0f,

		-0.5f, 0.5f, 0.5f, 0.0f, 0.0f,
		-0.5f, 0.5f, -0.5f, 1.0f, 0.0f,
		-0.5f, -0.5f, -0.5f, 1.0f, -1.0f,
		-0.5f, -0.5f, -0.5f, 1.0f, -1.0f,
		-0.5f, -0.5f, 0.5f, 0.0f, -1.0f,
		-0.5f, 0.5f, 0.5f, 0.0f, 0.0f,

		0.5f, 0.5f, 0.5f, 0.0f, 0.0f,
		0.5f, 0.5f, -0.5f, 1.0f, 0.0f,
		0.5f, -0.5f, -0.5f, 1.0f, -1.0f,
		0.5f, -0.5f, -0.5f, 1.0f, -1.0f,
		0.5f, -0.5f, 0.5f, 0.0f, -1.0f,
		0.5f, 0.5f, 0.5f, 0.0f, 0.0f,

		-0.5f, -0.5f, -0.5f, 0.0f, 1.0f,
		0.5f, -0.5f, -0.5f, 1.0f, 1.0f,
		0.5f, -0.5f, 0.5f, 1.0f, 0.0f,
		0.5f, -0.5f, 0.5f, 1.0f, 0.0f,
		-0.5f, -0.5f, 0.5f, 0.0f, 0.0f,
		-0.5f, -0.5f, -0.5f, 0.0f, 1.0f,

		-0.5f, 0.5f, -0.5f, 0.0f, 1.0f,
		0.5f, 0.5f, -0.5f, 1.0f, 1.0f,
		0.5f, 0.5f, 0.5f, 1.0f, 0.0f,
		0.5f, 0.5f, 0.5f, 1.0f, 0.0f,
		-0.5f, 0.5f, 0.5f, 0.0f, 0.0f,
		-0.5f, 0.5f, -0.5f, 0.0f, 1.0f
	};

	//generate a texture in gpu, return id
	unsigned int texture1ID;
	glGenTextures(1, &texture1ID);
	//we bind the texture to make it the one we're working on
	glBindTexture(GL_TEXTURE_2D, texture1ID);
	//set wrapping options(repeat texture if texture coordinates dont fully cover polygons)
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);//wrap on the s(x) axis
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);//wraps on the t(y) axis
	//set filtering options
	//Suggestion use nearest neighbour for pixel art, use bilinear for pretty much everything else
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);//GL_LINEAR(bilinear) or GL_NEAREST for shrinking
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);//for stretching


	//LOAD UP IMAGE FILE (JPEG FIRST)
	int width, height, numberChannels; //as we load an image, we'll get values from it to fill these in
	unsigned char *image1Data = stbi_load("box.png", &width, &height, &numberChannels, 0);
	//if it loaded
	if (image1Data){
		cout << "Success! Image is " << width << " by " << height << "pixels" << endl;
		//Lets associate our texture with this image data
		//params:
		//	texture type
		//	0= mipmap level(if you want to set manually, zero = nah)
		//  GL_RGB = format we want to store the texture data in
		//  width/height = size of texture
		//  0 = must always be zero, some legacy shit
		//	GL_RGB = if jpg, its considered RGB
		//	GL_UNSIGNED_BYTE = how the data has been loaded up for iamge1Data (unsigned char, char = byte)
		//	image1Data = our image data
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image1Data);
		//note: above tells openGL how to take someting from ram and store it in vram against our textureID

		//generate mipmaps for this texture
		glGenerateMipmap(GL_TEXTURE_2D);
			//generates a bunch of smaller versions of the texture to be used at great distances so save on
			//processing


	}
	else
	{
		cout << "Image load failed!" << endl;
	}
	//cleanup image memory
	stbi_image_free(image1Data);



	//Generate a texture in our graphics card to work with
	unsigned int texture2ID;
	glGenTextures(1, &texture2ID); //generate 1 texture id and store in texture2ID
	glBindTexture(GL_TEXTURE_2D, texture2ID);//make this texture the currently working texture, sayings its a 2d texture (as opposed to 1d and 3d)
	//how will texture repeat on large surfaces
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_MIRRORED_REPEAT);//how wrap horizontally (S axis...)
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);//how to wrap vertically (T axis..)
	//how will texture deal with shrink and stretch
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR); //when shrinking texture use bilinear filter
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);//use nearest neighbour filtering on stretch

	//Load up an image
	unsigned char *imageData2 = stbi_load("score.png", &width, &height, &numberChannels, 0);
	if (imageData2){
		//give the texture in our graphics card the data from this png file
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, imageData2);
		//generate mipmaps for this texture
		glGenerateMipmap(GL_TEXTURE_2D);
	}
	else
	{
		cout << "failed to load score" << endl;
	}
	//free image data from ram because theres a copy in the texture
	stbi_image_free(imageData2);




		//tell it how to feed this vertex data into the vertex shader
		//params:
			//0 = variable location in our vertex shader program(aPos)
			//3 = how many values make up a vertex in our data (1-4)
			//GL_FLOAT = what datatype to map to in the shader
			//GL_FALSE = 
			//3*sizeof(float) = Stride(how to find the next vertex), after current, the next is 3 floats up
			//(void*)0 = must be (void*) type..., but the zero is 'what is the starting index of your data'
		glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);
		//enable this variable location slot in our vertex shader
		glEnableVertexAttribArray(0); //vec3 aPos

	//finished binding information to current VAO, set binding to nothing for safety
	glBindVertexArray(0);


	

	//1. Vertex represents what data? position(xyz), colour(rgb), texture Coordinates(Ts, Tt)

	//2. Vertex Buffer Object? store vertices in the GPU
	unsigned int cubeVBO;
	glGenBuffers(1, &cubeVBO);

	//3. Vertex Array Object? tries to describe the data in the VBO and relay it to the first shader
	unsigned int cubeVAO;
	glGenVertexArrays(1, &cubeVAO);

	glBindVertexArray(cubeVAO);
	glBindBuffer(GL_ARRAY_BUFFER, cubeVBO);

	glBufferData(GL_ARRAY_BUFFER, sizeof(textureCubVertices), textureCubVertices, GL_STATIC_DRAW);

	//xyz to location = 0
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)0);
	glEnableVertexAttribArray(0);

	//texture coordinates to location = 1
	glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)(3 * sizeof(float)));
	glEnableVertexAttribArray(1);

	//unbind stuff
	glBindBuffer(GL_ARRAY_BUFFER, 0);
	glBindVertexArray(0);


	//array of 1 trophy positions
	glm::vec3 cubePositions[] = {
		glm::vec3(0.0f, 0.0f, 0.0f),
		
	};


	//GAME LOOP
	while (!glfwWindowShouldClose(window))
	{
		//update our time management stuff
		float currentFrame = (float)glfwGetTime();
		deltaTime = currentFrame - lastFrame;
		lastFrame = currentFrame;

		//user inputs
		processInputs(window);
		

		//RENDER STUFF
		//set openGL clear colour
		glClearColor(0,0,1,1);//r,g,b,a as floats, 0 to 1
		//clear screen AND clear Z depth buffer
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		shaderProgram2.use();
		//bind VAO to draw with
		glBindVertexArray(cubeVAO);



		//set active textures
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, texture1ID);
		glActiveTexture(GL_TEXTURE1);
		glBindTexture(GL_TEXTURE_2D, texture2ID);

		//set texture uniforms: tell each texture uniform which texture slot to use
		glUniform1i(glGetUniformLocation(shaderProgram2.ID, "texture1"), 0); //GL_TEXTURE0
		glUniform1i(glGetUniformLocation(shaderProgram2.ID, "texture2"), 1); //GL_TEXTURE1


		//Coordinate systems:
		//cube's vertices are in LOCAL SPACE, we need to convert it to WORLD space
		//glm::mat4 model = glm::mat4(1.0f);
		//rotate our cube
		//model = glm::rotate(model, (float)glfwGetTime(), glm::vec3(0.5f, 1.0f, 0.0f));
		//convert WORLD SPACE to VIEW SPACE (adjust stuff based on where camera is looking)
		glm::mat4 view = camera.GetViewMatrix();
		//view = glm::translate(view, glm::vec3(0.0f, 0.0f, -3.0f)); //push objects away to simulate moving camera backwards
		//float radius = 5.0f;
		//float camX = sin(glfwGetTime())*radius;
		//float camZ = cos(glfwGetTime())*radius;

		//lookat				cameraPosition				targetPosition			which way is up
		//view = glm::lookAt(glm::vec3(camX, 0, camZ), glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3(0.0f, 1.0f, 0.0f));


		//projection matrix helps create the mathematical illusion of perspective
		glm::mat4 projection = glm::perspective(glm::radians(camera.Zoom), 800.0f / 600.0f, 0.1f, 100.0f);

		//to set uniform values on shader
		//glUniformMatrix4fv(glGetUniformLocation(shaderProgram4.ID, "model"), 1, GL_FALSE, glm::value_ptr(model));
		glUniformMatrix4fv(glGetUniformLocation(shaderProgram2.ID, "view"), 1, GL_FALSE, glm::value_ptr(view));
		glUniformMatrix4fv(glGetUniformLocation(shaderProgram2.ID, "projection"), 1, GL_FALSE, glm::value_ptr(projection));


		//loop through to create a model matrix per cube position
		for (int i = 0; i < 10; i++){
			glm::mat4 model = glm::mat4(1.0f);
			model = glm::translate(model, cubePositions[i]);
			if (i%2 == 0)
				model = glm::rotate(model, (float)glfwGetTime(), glm::vec3(0.0f, 1.0f, 0.0f));
			else
				model = glm::rotate(model, (float)glfwGetTime()*glm::radians(50.0f), glm::vec3(1.0f, 0.5f, 0.0f));
			glUniformMatrix4fv(glGetUniformLocation(shaderProgram2.ID, "model"), 1, GL_FALSE, glm::value_ptr(model));
			glDrawArrays(GL_TRIANGLES, 0, 36); //strarting at stride0, draw 36 rows of vertex data
		}


		//Input for window
		glfwPollEvents();

		//swap render buffers with this loops rendered scene
		glfwSwapBuffers(window);

		showFPS(window);
	}

	//optional: de-allocate all resources
	
	//glDeleteBuffers(2, VBOs); //example of deleting 2 VBO ids from the VBOs array


	glfwTerminate();
}


//user inputs
void processInputs(GLFWwindow* window){
	//if esc pressed, set window to 'should close'
	if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
		glfwSetWindowShouldClose(window, true);
	if (glfwGetKey(window, GLFW_KEY_P) ==GLFW_PRESS ){
		//flip wiremode value
		wireFrame = !wireFrame;
		if (wireFrame) //if(wireframe == true)
			glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
		else
			glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
	}
	
}

void showFPS(GLFWwindow* window){
	//static function variables are declared 
	//once per project run, so these 2 lines of 
	//code run once and then the variables persist
	//until the end of the program
	static double previousSeconds = 0.0;
	static int frameCount = 0;
	double elapsedSeconds;
	double currentSeconds = glfwGetTime();
		//getTime returns seconds since startup

	elapsedSeconds = currentSeconds - previousSeconds;
	if (elapsedSeconds > 0.25){
		previousSeconds = currentSeconds;
		double fps = frameCount / elapsedSeconds;
		double msPerFrame = 1000.0 / fps;

		stringstream ss;
		ss.precision(3);//3 decimal places
		ss << fixed << "Game1 FPS: " << fps << " Frame Time: " << msPerFrame << "(ms)";

		glfwSetWindowTitle(window, ss.str().c_str());
		frameCount = 0;
	}
	frameCount++;
}

